# BUILD_INSTRUCTIONS.md — Reproduce the audit build

## Environment requirements

- OS: Linux / macOS / Windows (WSL2 recommended for exact byte match)
- Foundry: 0.2.0+ (`curl -L https://foundry.paradigm.xyz | bash; foundryup`)
- Solc: 0.8.28 (auto-downloaded by forge)
- Git: any recent version

## Steps

### 1. Clone

```bash
git clone https://github.com/Multyr/multyr-strategies
cd multyr-strategies
git checkout a658132af26342b6b0a36dafaba6897c16d4d5f1
```

### 2. Install dependencies

```bash
forge install
```

### 3. Build

```bash
forge clean
forge build
```

Expected output: `Compiler run successful` with warnings only (no errors).

### 4. Verify bytecode determinism

Run twice and compare:

```bash
forge inspect UsdcMultiLendingVault bytecode | sha256sum  # run 1
forge clean
forge build
forge inspect UsdcMultiLendingVault bytecode | sha256sum  # run 2
# Hashes must be identical
```

### 5. Run tests

```bash
forge test --match-path "test/strategies/usdc-lending/**" -vv
```

Expected: `2358 tests passed, 0 failed, 3 skipped`

The 3 skipped tests require RPC env vars (fork tests):
- `ARBITRUM_RPC_URL` — for V92 Arbitrum fork tests
- `OPTIMISM_RPC_URL` — for V92 Optimism fork test
- `BASE_RPC_URL` — for V92 Base fork test

### 6. Run formal verification (optional)

Halmos (symbolic execution):
```bash
halmos --contract HalmosProofsP07 --function check_ --loop 256
# Expected: 23/23 PASS
```

Echidna (fuzzing):
```bash
echidna test/strategies/usdc-lending/echidna/EchidnaSafetyAdapterCapTier.sol \
  --config echidna.yaml --test-limit 1000000
# Expected: 15/15 invariants PASS, 0 counter-examples
```

## Key foundry.toml settings

```toml
[profile.default]
evm_version     = "cancun"
bytecode_hash   = "none"   # eliminates non-deterministic IPFS hash in bytecode
cbor_metadata   = false    # removes CBOR metadata tail
solc_version    = "0.8.28" # pinned exact version
```

These settings guarantee byte-identical deployed bytecode across all build environments.