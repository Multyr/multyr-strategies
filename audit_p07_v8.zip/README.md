# audit_p07_v8 — USDC Lending Strategy V10 Audit Submission Package

**Prepared for**: Spearbit / Sherlock  
**Version**: v10.0.0 (feature/v10.0-storage-initialize)  
**HEAD commit**: a658132af26342b6b0a36dafaba6897c16d4d5f1  
**Date**: 2026-06-21  
**Repository**: Multyr/multyr-strategies (private)

---

## Package contents

| Directory | Contents |
|---|---|
| `00_summary/` | Executive summary (WAVE1_2_SUMMARY.md), CHANGELOG, audit-scope |
| `01_source/` | Full Solidity source: `src/strategies/usdc-lending/` (32 files) |
| `02_tests/` | Full test suite: `test/strategies/usdc-lending/` (69 files, 2358 passing) |
| `03_docs/` | Architecture docs: overview, adapters, invariants, threat-model, V10 docs |
| `04_audit_evidence/` | Halmos 23/23, Echidna 15/15 1M, refactor logs, contract sizes |
| `05_config/` | foundry.toml (deterministic build config) + all 5 chain configs |
| `06_meta/` | Commit list, build instructions, SHA256 manifest |

---

## Quick start — reproduce the build

Prerequisites: Foundry 0.2.0+, Solc 0.8.28

```bash
# Clone + install deps
git clone https://github.com/Multyr/multyr-strategies --branch feature/v10.0-storage-initialize
cd multyr-strategies
git checkout a658132

# Build (deterministic)
forge build

# Run all tests
forge test --match-path "test/strategies/usdc-lending/**"
# Expected: 2358 passed, 0 failed, 3 skipped

# Verify bytecode determinism (run twice, compare hash)
forge inspect UsdcMultiLendingVault bytecode | sha256sum
```

---

## Scope

**In scope**: all 32 files in `src/strategies/usdc-lending/` — see `00_summary/audit-scope.md`.  
**Out of scope**: scripts, chain config libraries (pure functions, no logic), submodules.

---

## Key claims

1. **Wave 1**: 15 security findings fixed (4 CRITICAL, 11 HIGH) — see `00_summary/WAVE1_2_SUMMARY.md`
2. **Wave 2**: Build determinism + formal verification (Halmos 23/23, Echidna 15/15) — see `04_audit_evidence/`
3. **Wave 3**: Byte-identical bytecode across 5 chains — see `03_docs/v10/MULTICHAIN_PLAYBOOK.md`
4. **Test gate**: 2358/0/3 (passed/failed/skipped) — all failures zero
5. **EIP-170**: All production contracts ≤ 23,552 B (project 1KB-safety rule) — see `04_audit_evidence/sizes/`

---

## Build configuration (foundry.toml)

```toml
[profile.default]
evm_version = "cancun"
bytecode_hash = "none"   # eliminates IPFS suffix from deployed bytecode
cbor_metadata = false    # removes CBOR metadata tail — byte-identical builds
solc_version = "0.8.28"
```

This configuration ensures byte-identical deployed bytecode across machines, CI environments,
and deployment chains. A single Spearbit/Sherlock audit covers all chain deployments.